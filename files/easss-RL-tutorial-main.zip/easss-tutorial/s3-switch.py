from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from _env.gridMatrix import GridWorldObstaclesMatrix
from stable_baselines3.common.logger import configure
from utils.callback import EpisodeStatsCallback
from utils.switch import SwitchingEnvsWrapper
import numpy as np
from datetime import datetime
import os
import argparse
import time

# Random environment generation with a different number, position of obstacles, position of goal
def generate_random_env(grid_size, cutoff=1000):
    obstacles = []
    num_obstacles = np.random.randint(1, min(grid_size[0], grid_size[1]))
    for _ in range(num_obstacles):
        obstacles.append((np.random.randint(grid_size[0]), np.random.randint(grid_size[1])))

    goal = (np.random.randint(grid_size[0]), np.random.randint(grid_size[1]))
    while goal in obstacles or goal == (0, 0):
        goal = (np.random.randint(grid_size[0]), np.random.randint(grid_size[1]))

    return GridWorldObstaclesMatrix(grid_size, obstacles, goal, cutoff)

# Environments to generate
num_envs = 20
grid_size = (5, 5)
cutoff = 500
switch_interval = 1

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", type=str, default="run")
    args = parser.parse_args()

    envs = [generate_random_env(grid_size, cutoff=cutoff) for _ in range(num_envs)]
    env = SwitchingEnvsWrapper(envs, switch_every=switch_interval)

    # Define DQN hyperparameters
    epsilon_initial = 1.0  # Initial value of epsilon
    epsilon_final = 0.01   # Final value of epsilon
    epsilon_decay = 0.8  # Decay factor for epsilon
    gamma = 0.99

    model = DQN(
        'MultiInputPolicy',
        env,
        verbose=1,
        exploration_initial_eps=epsilon_initial,
        exploration_final_eps=epsilon_final,
        exploration_fraction=epsilon_decay,
        gamma=gamma
    )
    exp_path = os.path.join("logs/", datetime.now().strftime("%Y%m%d-%H%M%S") + "_matrix_switch_" + args.name)
    new_logger = configure(exp_path, ["stdout", "csv", "tensorboard"])
    model.set_logger(new_logger)

    # Train
    model.learn(total_timesteps=10000, callback=EpisodeStatsCallback())

    # Save
    model.save(os.path.join(exp_path,"dqn_gridworld"))

    # Test
    print("++++++++++++++++++++++++++++++")
    for episode in range(5):
        print("Episode: ", episode)
        obs, _ = env.reset()
        for _ in range(100):
            env.render()
            action, _ = model.predict(obs)
            action = int(action)
            print("Action: ", action)
            obs, rewards, done, truncated, info = env.step(action)
            time.sleep(0.1)
            if done:
                print("Agent reached the goal!")
                break
        print("++++++++++++++++++++++++++++++")