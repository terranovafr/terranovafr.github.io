import gymnasium as gym
from gymnasium import spaces
import numpy as np

class GridWorldObstaclesFeatures(gym.Env):

    def __init__(self, grid_size, obstacles, goal, cutoff, render_mode='human'):
        super(GridWorldObstaclesFeatures, self).__init__()
        # Now grid size is customizable
        self.grid_size = grid_size
        self.obstacles = obstacles
        self.goal = goal
        self.cutoff = cutoff

        self.action_space = spaces.Discrete(4)

        self.observation_space = spaces.Dict({
            "agent_x": spaces.Box(low=0, high=30, shape=(1,), dtype=np.float32),  # Agent x position
            "agent_y": spaces.Box(low=0, high=30, shape=(1,), dtype=np.float32),  # Agent y position
            "goal_x_distance": spaces.Box(low=0, high=30, shape=(1,), dtype=np.float32), # Distance to goal in x-direction
            "goal_y_distance": spaces.Box(low=0, high=30, shape=(1,), dtype=np.float32), # Distance to goal in y-direction
            "num_obstacles_nearby": spaces.Box(low=0, high=9, shape=(1,), dtype=np.float32) # Number of obstacles within a distance of 1 cell
        })

        self.render_mode = render_mode

    def reset(self, seed=None, **kwargs):
        self.agent_position = (0, 0)
        self.step_count = 0

        # Compute features
        obs = self._get_obs()
        return obs, {}

    def step(self, action):
        actions = {
            0: (-1, 0),  # Left
            1: (1, 0),  # Right
            2: (0, -1),  # Up
            3: (0, 1)  # Down
        }

        delta = actions[action]
        new_position = (
            self.agent_position[0] + delta[0],
            self.agent_position[1] + delta[1]
        )


        if (0 <= new_position[0] < self.grid_size[0] and
                0 <= new_position[1] < self.grid_size[1]):

            if new_position in self.obstacles:
                reward = -10
            elif new_position == self.goal:
                reward = 100
            else:
                reward = -1

            self.agent_position = new_position
        else:
            reward = -5

        done = self.agent_position == self.goal
        self.step_count += 1
        truncated = self.step_count >= self.cutoff

        # Return new features
        obs = self._get_obs()
        return obs, reward, done, truncated, {}


    def _get_obs(self):
        # Get agent position
        agent_x, agent_y = self.agent_position
        goal_x, goal_y = self.goal

        # Calculate distances to goal
        goal_x_distance = abs(agent_x - goal_x)
        goal_y_distance = abs(agent_y - goal_y)

        # Calculate number of obstacles nearby (within a distance of 1 cell)
        num_obstacles_nearby = 0
        for obs_x, obs_y in self.obstacles:
            if abs(agent_x - obs_x) <= 1 and abs(agent_y - obs_y) <= 1:
                num_obstacles_nearby += 1

        return {
            "agent_x": agent_x,
            "agent_y": agent_y,
            "goal_x_distance": goal_x_distance,
            "goal_y_distance": goal_y_distance,
            "num_obstacles_nearby": num_obstacles_nearby
        }

    def render(self, mode='human'):
        if self.render_mode == 'human' and mode == self.render_mode:
            grid = [['-' for _ in range(self.grid_size[1])] for _ in range(self.grid_size[0])]

            for obs in self.obstacles:
                if 0 <= obs[0] < self.grid_size[0] and 0 <= obs[1] < self.grid_size[1]:
                    grid[obs[0]][obs[1]] = 'O'

            if 0 <= self.goal[0] < self.grid_size[0] and 0 <= self.goal[1] < self.grid_size[1]:
                grid[self.goal[0]][self.goal[1]] = 'G'

            if 0 <= self.agent_position[0] < self.grid_size[0] and 0 <= self.agent_position[1] < self.grid_size[1]:
                grid[self.agent_position[0]][self.agent_position[1]] = 'A'

            print('+' + '-' * self.grid_size[1] + '+')

            for row in grid:
                print('|' + ''.join(row) + '|')

            print('+' + '-' * self.grid_size[1] + '+')
        else:
            print("Unsupported render mode. Use 'human' mode.")
