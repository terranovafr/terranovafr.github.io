import numpy as np
from collections import deque
from stable_baselines3.common.callbacks import BaseCallback

# Logs episode stats in the classic box format and on tensorboard
class EpisodeStatsCallback(BaseCallback):
    def __init__(self, verbose=0, window_size=100):
        super(EpisodeStatsCallback, self).__init__(verbose)
        self.window_size = window_size
        # Use mean over the last window_size episodes
        self.episode_rewards = deque(maxlen=window_size)
        self.episode_lengths = deque(maxlen=window_size)
        self.current_rewards = []
        self.current_length = 0

    def _on_step(self) -> bool:
        # If the episode has finished, done == True
        if self.locals['dones'][0]:
            self.current_rewards.append(self.locals['rewards'][0])
            self.current_length += 1
            episode_reward = np.sum(self.current_rewards)

            # Save new stats
            self.episode_rewards.append(episode_reward)
            self.episode_lengths.append(self.current_length)

            self.current_rewards = []
            self.current_length = 0
        else:
            self.current_rewards.append(self.locals['rewards'][0])
            self.current_length += 1
        return True

    def _on_rollout_end(self):
        if self.episode_rewards:
            # Log the stats
            mean_reward = np.mean(self.episode_rewards)
            mean_length = np.mean(self.episode_lengths)
            self.logger.record('rollout/ep_rew_mean', mean_reward)
            self.logger.record('rollout/ep_len_mean', mean_length)
            self.logger.dump(step=self.num_timesteps)

