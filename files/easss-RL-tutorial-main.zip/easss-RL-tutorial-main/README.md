# EASSS Tutorial: Deep Reinforcement Learning - Foundations and Practical Environment Setup for Real-World Applications 

## Getting Started

This repository contains a tutorial for leveraging Reinforcement Learning (RL) to learn from Grid World environments. The tutorial includes various exercises that demonstrate different potential implementations of the environment, mainly focusing on the observation space.

## Repository Structure

- **_env**: Contains multiple implementations of the Grid World environment with varying observation spaces.
- **utils**: Includes utility functions for logging and environment switching.
- **environment.yaml** or **requirements.txt**: Specifies the environment configuration required to run the tutorial.
- **s1-pomdp, s2-mdp, etc. Files**: Each file contains a different exercise of the tutorial, demonstrating various methodologies.

## Installation

To set up the environment, you can use Conda and run the following command:

```bash
conda env create --name rleasss
conda activate rleasss
pip install stable-baselines3 tensorboard
```

Or use the requirements.txt file:

```bash
conda env create --name rleasss
conda activate rleasss
pip install -r requirements.txt
```

Or use the attached environment.yml file:

```bash
conda env create -f environment.yml
conda activate rleasss
```

If you use venv, do the same steps and use the requirements.txt file or the manual installation:
```bash
python -m venv myenv
source myenv/bin/activate
pip install -r requirements.txt
```

However, with MacOS some issues may arise based on the numpy version. In that case downgrade numpy to a version lower than 2.0:
```bash
pip install "numpy<2"
```

## Exercises

Each exercise is contained in separate files named s1-a.py, s2-b.py, and so on.  To run an exercise, execute the corresponding file.

**Example**:
```sh
python s1-pomdp.py
```

## Logging and Environment Switching

The utils folder contains utility functions that assist with logging the training progress and switching environments periodically during training. 
If the custom logger defined in this folder is used, a logs folder will be created under the folder "logs" to store tensorboard logs, the final checkpoint of the neural network and a csv progress file.