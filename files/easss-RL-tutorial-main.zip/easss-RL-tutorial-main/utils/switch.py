import gymnasium as gym

# Periodically switching the environment with a different configuration of the grid, we ensure the agent may learn a general mapping
class SwitchingEnvsWrapper(gym.Wrapper):
    def __init__(self, envs, switch_every):
        # List of environments to switch between
        self.envs = envs
        # interval for switching environments
        self.switch_every = switch_every
        self.current_env_index = 0
        self.episode_count = 0
        super(SwitchingEnvsWrapper, self).__init__(self.envs[self.current_env_index])

    def reset(self, **kwargs):
        if self.episode_count >= self.switch_every:
            self.current_env_index = (self.current_env_index + 1) % len(self.envs)
            self.env = self.envs[self.current_env_index]
            self.episode_count = 0
        self.episode_count += 1
        return self.env.reset(**kwargs)

    def step(self, action):
        return self.env.step(action)

