import gymnasium as gym
from gymnasium import spaces
import numpy as np

class GridWorldObstaclesCNN(gym.Env):
    def __init__(self, grid_size, obstacles, goal, cutoff, render_mode='human'):
        super(GridWorldObstaclesCNN, self).__init__()

        self.grid_size = grid_size
        self.obstacles = obstacles
        self.goal = goal
        self.cutoff = cutoff

        self.action_space = spaces.Discrete(4)

        # Define observation space as a 3D Box (height, width, channels)
        self.observation_space = spaces.Box(low=0, high=255, shape=(10, 10, 1), dtype=np.uint8)

        self.render_mode = render_mode

    def reset(self, seed=None, return_info=True, **kwargs):
        self.agent_position = (0, 0)
        self.step_count = 0

        # Update the observation matrix based on initial state
        self.obs_matrix = np.zeros((10, 10), dtype=np.uint8)
        self._update_obs_matrix()
        obs = self._get_obs()

        return obs, {}

    def step(self, action):
        actions = {
            0: (-1, 0),  # Left
            1: (1, 0),  # Right
            2: (0, -1),  # Up
            3: (0, 1)  # Down
        }

        delta = actions[action]
        new_position = (
            self.agent_position[0] + delta[0],
            self.agent_position[1] + delta[1]
        )

        if (0 <= new_position[0] < self.grid_size[0] and
                0 <= new_position[1] < self.grid_size[1]):

            if new_position in self.obstacles:
                reward = -10
            elif new_position == self.goal:
                reward = 100
            else:
                reward = -1

            self.agent_position = new_position
        else:
            reward = -5

        done = self.agent_position == self.goal
        self.step_count += 1
        truncated = self.step_count >= self.cutoff

        # Update the observation matrix
        self._update_obs_matrix()
        obs = self._get_obs()

        return obs, reward, done, truncated, {}


    def _update_obs_matrix(self):
        self.obs_matrix.fill(0)

        # Create a copycut of an image, setting information as grayscale values

        # Set agent position
        self.obs_matrix[self.agent_position[0], self.agent_position[1]] = 85  # Set agent position to 85

        for obs in self.obstacles:
            self.obs_matrix[obs[0], obs[1]] = 170  # Set obstacles to 170

        # Set goal
        self.obs_matrix[self.goal[0], self.goal[1]] = 255  # Set goal to 255


    def _get_obs(self):
        return self.obs_matrix[..., np.newaxis]  # Add a channel dimension

    def render(self, mode='human'):
        if self.render_mode == 'human' and mode == self.render_mode:

            # Arid filled with '-'
            grid = [['-' for _ in range(self.grid_size[1])] for _ in range(self.grid_size[0])]

            # Place obstacles
            for obs in self.obstacles:
                if 0 <= obs[0] < self.grid_size[0] and 0 <= obs[1] < self.grid_size[1]:
                    grid[obs[0]][obs[1]] = 'O'

            # Place goal
            if 0 <= self.goal[0] < self.grid_size[0] and 0 <= self.goal[1] < self.grid_size[1]:
                grid[self.goal[0]][self.goal[1]] = 'G'

            # Place agent
            if 0 <= self.agent_position[0] < self.grid_size[0] and 0 <= self.agent_position[1] < self.grid_size[1]:
                grid[self.agent_position[0]][self.agent_position[1]] = 'A'

            # Borders
            print('+' + '-' * self.grid_size[1] + '+')
            for row in grid:
                print('|' + ''.join(row) + '|')
            print('+' + '-' * self.grid_size[1] + '+')
        else:
            print("Unsupported render mode. Use 'human' mode.")


