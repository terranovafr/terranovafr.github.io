from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from _env.gridXY import GridWorldObstaclesXY
from stable_baselines3.common.logger import configure
from utils.callback import EpisodeStatsCallback
from datetime import datetime
import os
import time
import argparse

### First Example
grid_size = (3, 3)
obstacles = [(0, 2), (1, 1)]
goal = (2, 2)
# Second Example
#grid_size = (5, 5)
#obstacles = [(0, 2), (0, 1), (2,1), (3, 0)]
#goal = (4, 4)

cutoff = 1000

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", type=str, default="run")
    args = parser.parse_args()

    # Environment version
    env = GridWorldObstaclesXY(grid_size, obstacles, goal, cutoff=cutoff)

    # Define DQN hyperparameters
    epsilon_initial = 1.0  # Initial value of epsilon
    epsilon_final = 0.01   # Final value of epsilon
    epsilon_decay = 0.8  # Decay factor for epsilon
    gamma = 0.99

    env = DummyVecEnv([lambda: env])

    # Create the model with custom hyperparameters
    model = DQN(
        'MultiInputPolicy',
        env=env,
        verbose=1,
        exploration_initial_eps=epsilon_initial,
        exploration_final_eps=epsilon_final,
        exploration_fraction=epsilon_decay,
        gamma=gamma
    )

    # Logging
    exp_path = os.path.join("logs/", datetime.now().strftime("%Y%m%d-%H%M%S") + "_xy_" + args.name)
    new_logger = configure(exp_path, ["stdout", "csv", "tensorboard"])
    model.set_logger(new_logger)

    # Train
    model.learn(total_timesteps=50000, callback=EpisodeStatsCallback())

    # Save
    model.save(os.path.join(exp_path,"dqn_gridworld"))

    # Test and debug
    obs = env.reset()
    for _ in range(100):
        env.render()
        action, _ = model.predict(obs)
        print("Action: ", action[0])
        obs, rewards, done, info = env.step(action)
        time.sleep(0.1)
        if done:
            print("Agent reached the goal!")
            break
