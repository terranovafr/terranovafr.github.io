from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.logger import configure
from utils.callback import EpisodeStatsCallback
from utils.switch import SwitchingEnvsWrapper
from datetime import datetime
import os
import numpy as np
from _env.gridFeatures import GridWorldObstaclesFeatures
import argparse

# Extend the generation to support also dynamic grid sizes
def generate_random_env(min_size, max_size, cutoff):
    grid_width = np.random.randint(min_size[0], max_size[0] + 1)
    grid_height = np.random.randint(min_size[1], max_size[1] + 1)
    grid_size = (grid_width, grid_height)
    obstacles = []
    num_obstacles = np.random.randint(1, min(grid_size[0], grid_size[1]))
    for _ in range(num_obstacles):
        obstacles.append((np.random.randint(grid_size[0]), np.random.randint(grid_size[1])))
    goal = (np.random.randint(grid_size[0]), np.random.randint(grid_size[1]))
    while goal in obstacles:
        goal = (np.random.randint(grid_size[0]), np.random.randint(grid_size[1]))
    return GridWorldObstaclesFeatures(grid_size, obstacles, goal, cutoff)

# Environments to generate with now grid size
num_envs = 20
min_size = (3, 3)
max_size = (5, 5)
cutoff = 20
switch_interval = 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", type=str, default="run")
    args = parser.parse_args()

    envs = [generate_random_env(min_size, max_size, cutoff) for _ in range(num_envs)]
    env = SwitchingEnvsWrapper(envs, switch_every=switch_interval)
    env = DummyVecEnv([lambda: env])

    # Define DQN hyperparameters
    epsilon_initial = 1.0  # Initial value of epsilon
    epsilon_final = 0.01   # Final value of epsilon
    epsilon_decay = 0.7  # Decay factor for epsilon
    gamma = 0.99

    # Create the model with custom hyperparameters
    model = DQN(
        'MultiInputPolicy',
        env,
        verbose=1,
        exploration_initial_eps=epsilon_initial,
        exploration_final_eps=epsilon_final,
        exploration_fraction=epsilon_decay,
        gamma=gamma
    )

    exp_name = "_features_switch_" + args.name
    # Log
    exp_path = os.path.join("logs/", datetime.now().strftime("%Y%m%d-%H%M%S") + exp_name)
    new_logger = configure(exp_path, ["stdout", "csv", "tensorboard"])
    model.set_logger(new_logger)

    # Train
    model.learn(total_timesteps=50000, callback=EpisodeStatsCallback())

    # Save
    model.save(os.path.join(exp_path,"dqn_gridworld"))

    # Test
    obs = env.reset()
    for _ in range(1000):
        action, _ = model.predict(obs)
        obs, rewards, done, info = env.step(action)
        env.render()
        if done:
            obs = env.reset()