import gym
from gym import spaces
import numpy as np

class GridWorldObstaclesMatrix(gym.Env):
    def __init__(self, grid_size, obstacles, goal, cutoff, render_mode='human'):
        super(GridWorldObstaclesMatrix, self).__init__()

        self.grid_size = grid_size
        self.obstacles = obstacles
        self.goal = goal
        self.cutoff = cutoff

        self.action_space = spaces.Discrete(4)
        # Observation space now proportional to the number of cells, and with 4 states each (empty, obstacle, goal, agent)
        self.observation_space = spaces.Dict({
            f"cell_{i}_{j}": spaces.Discrete(4) for i in range(grid_size[0]) for j in range(grid_size[1])
        })

        self.reset()
        self.render_mode = render_mode

    def reset(self, seed=None, return_info=True, **kwargs):
        self.seed(seed)
        self.agent_position = (0, 0)
        self.step_count = 0

        # Matrix to be updated at every step
        self.obs_matrix = np.zeros((self.grid_size[0], self.grid_size[1]), dtype=np.int32)
        self._update_obs_matrix()
        obs = self._get_obs()

        if return_info:
            return obs, {}

        return obs

    def step(self, action):
        actions = {
            0: (-1, 0),  # Left
            1: (1, 0),  # Right
            2: (0, -1),  # Up
            3: (0, 1)  # Down
        }

        delta = actions[action]
        new_position = (
            self.agent_position[0] + delta[0],
            self.agent_position[1] + delta[1]
        )

        if (0 <= new_position[0] < self.grid_size[0] and
                0 <= new_position[1] < self.grid_size[1]):

            if new_position in self.obstacles:
                reward = -10
            elif new_position == self.goal:
                reward = 100
            else:
                reward = -1

            self.agent_position = new_position
        else:
            reward = -5

        done = self.agent_position == self.goal
        self.step_count += 1
        truncated = self.step_count >= self.cutoff

        # Update the observation matrix
        self._update_obs_matrix()
        obs = self._get_obs()

        return obs, reward, done, truncated, {}

    def seed(self, seed=None):
        self.np_random, seed = gym.utils.seeding.np_random(seed)
        return [seed]

    def _update_obs_matrix(self):
        self.obs_matrix.fill(0)

        # Set obstacles
        for obs in self.obstacles:
            self.obs_matrix[obs[0], obs[1]] = 2

        # Set goal
        self.obs_matrix[self.goal[0], self.goal[1]] = 3

        # Set agent position
        self.obs_matrix[self.agent_position[0], self.agent_position[1]] = 1


    def _get_obs(self):
        # Return a dictionary with the observation matrix
        return {f"cell_{i}_{j}": self.obs_matrix[i, j] for i in range(self.grid_size[0]) for j in
                range(self.grid_size[1])}

    def render(self, mode='human'):
        if self.render_mode == 'human':
            grid = [['-' for _ in range(self.grid_size[1])] for _ in range(self.grid_size[0])]

            for obs in self.obstacles:
                if 0 <= obs[0] < self.grid_size[0] and 0 <= obs[1] < self.grid_size[1]:
                    grid[obs[0]][obs[1]] = 'O'

            if 0 <= self.goal[0] < self.grid_size[0] and 0 <= self.goal[1] < self.grid_size[1]:
                grid[self.goal[0]][self.goal[1]] = 'G'

            if 0 <= self.agent_position[0] < self.grid_size[0] and 0 <= self.agent_position[1] < self.grid_size[1]:
                grid[self.agent_position[0]][self.agent_position[1]] = 'A'

            print('+' + '-' * self.grid_size[1] + '+')

            for row in grid:
                print('|' + ''.join(row) + '|')

            print('+' + '-' * self.grid_size[1] + '+')
        else:
            raise ValueError(f"Unsupported render mode: {mode}")

