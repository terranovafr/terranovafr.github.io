import gym
from gym import spaces

class GridWorldObstaclesXY(gym.Env):
    def __init__(self, grid_size, obstacles, goal, cutoff, render_mode='human'):
        super(GridWorldObstaclesXY, self).__init__()
        self.grid_size = grid_size
        self.obstacles = obstacles
        self.goal = goal
        self.cutoff = cutoff  # Maximum number of steps before termination
        self.action_space = spaces.Discrete(4)  # Up, Down, Left, Right
        self.observation_space = spaces.Dict({
            'x': spaces.Discrete(grid_size[0]),
            'y': spaces.Discrete(grid_size[1]),
        })
        self.render_mode = render_mode

    def reset(self, seed=None, **kwargs):
        self.step_count = 0
        self.agent_position = (0, 0)
        obs = {'x': self.agent_position[0], 'y': self.agent_position[1]}
        return obs, {}

    def step(self, action):
        self.step_count += 1
        actions = {
            0: (-1, 0),  # Left
            1: (1, 0),  # Right
            2: (0, -1),  # Up
            3: (0, 1)  # Down
        }

        delta = actions[action]
        new_position = (
            self.agent_position[0] + delta[0],
            self.agent_position[1] + delta[1]
        )

        # Check if new position is within grid bounds
        if (0 <= new_position[0] < self.grid_size[0] and
                0 <= new_position[1] < self.grid_size[1]):

            # Check if new position is an obstacle or goal
            if new_position in self.obstacles:
                reward = -10 # Penalty for hitting an obstacle
            elif new_position == self.goal:
                reward = 100 # Reward for reaching the goal
            else:
                reward = -1 # Time penalty

            self.agent_position = new_position
        else:
            reward = -5  # Penalty for moving out of bounds

        done = self.agent_position == self.goal
        truncated = self.step_count >= self.cutoff
        obs = {'x': self.agent_position[0], 'y': self.agent_position[1]}
        return obs, reward, done, truncated, {}

    def render(self, mode='human'):
        if self.render_mode == 'human' and mode == self.render_mode:

            # Arid filled with '-'
            grid = [['-' for _ in range(self.grid_size[1])] for _ in range(self.grid_size[0])]

            # Place obstacles
            for obs in self.obstacles:
                if 0 <= obs[0] < self.grid_size[0] and 0 <= obs[1] < self.grid_size[1]:
                    grid[obs[0]][obs[1]] = 'O'

            # Place goal
            if 0 <= self.goal[0] < self.grid_size[0] and 0 <= self.goal[1] < self.grid_size[1]:
                grid[self.goal[0]][self.goal[1]] = 'G'

            # Place agent
            if 0 <= self.agent_position[0] < self.grid_size[0] and 0 <= self.agent_position[1] < self.grid_size[1]:
                grid[self.agent_position[0]][self.agent_position[1]] = 'A'

            # Borders
            print('+' + '-' * self.grid_size[1] + '+')
            for row in grid:
                print('|' + ''.join(row) + '|')
            print('+' + '-' * self.grid_size[1] + '+')
        else:
            print("Unsupported render mode. Use 'human' mode.")

