from stable_baselines3 import DQN
from stable_baselines3.common.vec_env import DummyVecEnv
from _env.gridCNN import GridWorldObstaclesCNN
from stable_baselines3.common.logger import configure
from utils.callback import EpisodeStatsCallback
from utils.switch import SwitchingEnvsWrapper
import numpy as np
from datetime import datetime
import os
from stable_baselines3.common.torch_layers import BaseFeaturesExtractor
import torch.nn as nn
import torch as th
from gymnasium import spaces
import argparse
import time

# Custom CNN for the policy
class CustomCNN(BaseFeaturesExtractor):
    def __init__(self, observation_space: spaces.Box, features_dim: int = 32):
        super(CustomCNN, self).__init__(observation_space, features_dim)
        n_input_channels = observation_space.shape[0]
        # The CNN can be customized
        self.cnn = nn.Sequential(
            nn.Conv2d(n_input_channels, 32, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Flatten()
        )

        # Compute shape by doing one forward pass
        with th.no_grad():
            n_flatten = self.cnn(th.as_tensor(observation_space.sample()[None]).float()).shape[1]

        # The flattened vector goes through a feed-forward layer
        self.linear = nn.Sequential(
            nn.Linear(n_flatten, features_dim),
            nn.ReLU()
        )

    def forward(self, observations: th.Tensor) -> th.Tensor:
        return self.linear(self.cnn(observations))


# Extend the generation to support also dynamic grid sizes
def generate_random_env(min_size, max_size, cutoff):
    grid_width = np.random.randint(min_size[0], max_size[0] + 1)
    grid_height = np.random.randint(min_size[1], max_size[1] + 1)
    grid_size = (grid_width, grid_height)
    obstacles = []
    num_obstacles = np.random.randint(1, min(grid_size[0], grid_size[1]))
    for _ in range(num_obstacles):
        obstacles.append((np.random.randint(grid_size[0]), np.random.randint(grid_size[1])))
    goal = (np.random.randint(grid_size[0]), np.random.randint(grid_size[1]))
    while goal in obstacles or goal == (0, 0):
        goal = (np.random.randint(grid_size[0]), np.random.randint(grid_size[1]))
    return GridWorldObstaclesCNN(grid_size, obstacles, goal, cutoff)

# Environments to generate
num_envs = 50
min_size = (3, 3)
max_size = (10, 10)
cutoff = 200
switch_interval = 1

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", type=str, default="run")
    args = parser.parse_args()

    envs = [generate_random_env(min_size, max_size, cutoff) for _ in range(num_envs)]
    env = SwitchingEnvsWrapper(envs, switch_every=switch_interval)
    env = DummyVecEnv([lambda: env])

    # Define DQN hyperparameters
    epsilon_initial = 1.0  # Initial value of epsilon
    epsilon_final = 0.01   # Final value of epsilon
    epsilon_decay = 0.7  # Decay factor for epsilon
    gamma = 0.99
    # Including now policy kwargs
    policy_kwargs = dict(
        features_extractor_class=CustomCNN,
        features_extractor_kwargs=dict(features_dim=32),
    )

    model = DQN(
        'CnnPolicy',  # Use 'CnnPolicy' instead of 'MultiInputPolicy'
        env,
        policy_kwargs=policy_kwargs,
        verbose=1,
        exploration_initial_eps=epsilon_initial,
        exploration_final_eps=epsilon_final,
        exploration_fraction=epsilon_decay,
        gamma=gamma
    )

    # Log
    exp_path = os.path.join("logs/", datetime.now().strftime("%Y%m%d-%H%M%S") + "_CNN_switch_" + args.name)
    new_logger = configure(exp_path, ["stdout", "csv", "tensorboard"])
    model.set_logger(new_logger)

    # Train
    model.learn(total_timesteps=100000, callback=EpisodeStatsCallback())

    # Save
    model.save(os.path.join(exp_path, "dqn_gridworld"))

    # Test
    print("++++++++++++++++++++++++++++++")
    for episode in range(5):
        print("Episode: ", episode)
        obs = env.reset()
        for _ in range(100):
            env.render()
            action, _ = model.predict(obs)
            print("Action: ", action[0])
            obs, rewards, done, info = env.step(action)
            time.sleep(0.1)
            if done:
                print("Agent reached the goal!")
                break
        print("++++++++++++++++++++++++++++++")
